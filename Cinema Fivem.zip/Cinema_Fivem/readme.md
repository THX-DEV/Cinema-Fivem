<h1 align='center'>[STANDALONE] OnlineM Cinemas</a></h1><p align='center'><b>GTA:Online Cinema Remastered</b></h5>

Wanna Watch some movies with your friends, but worried about **copyrighted** videos? No worrys! With this script, you can head on over to **any Cinema** across Los-Santos and watch the watch any of the **built in GTA Movies** and enjoy a fully **synchronised** experience with your friends !

## Preview
[![](https://media.discordapp.net/attachments/1177897486241763399/1188212443365785660/image.png?ex=6599b412&is=65873f12&hm=5b6204a57b9d457c6c2a8e97b4024734efa735febbed5c9a1146181011fff0f8&=&format=webp&quality=lossless&width=1830&height=910)]
## Notice

Copyright © 2023 Mycroft (ThX)

All rights reserved.

Permission is hereby granted, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software with 'All rights reserved'. Even if 'All rights reserved' is very clear :

  You shall not sell and/or resell this software
  You Can use and Modify this software
  You Shall Not Distribute and/or Redistribute the software
  The above copyright notice and this permission notice shall be included in all copies and files of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
